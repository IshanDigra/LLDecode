package Problems.HARD.Spotify.Constant;

public enum SongType {
    ROCK, ROMANTIC, INDIE_POP, PARTY
}
