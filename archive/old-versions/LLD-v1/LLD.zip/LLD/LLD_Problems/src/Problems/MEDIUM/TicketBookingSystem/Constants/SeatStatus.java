package Problems.MEDIUM.TicketBookingSystem.Constants;

public enum SeatStatus {
    AVAILABLE, RESERVED, BOOKED;
}
