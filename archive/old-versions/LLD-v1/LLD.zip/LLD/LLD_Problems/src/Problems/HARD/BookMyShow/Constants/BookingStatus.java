package Problems.HARD.BookMyShow.Constants;

public enum BookingStatus {
    PENDING, COMPLETED, CANCELLED;
}
