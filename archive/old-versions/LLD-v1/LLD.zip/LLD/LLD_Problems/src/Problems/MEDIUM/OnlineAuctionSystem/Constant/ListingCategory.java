package Problems.MEDIUM.OnlineAuctionSystem.Constant;

public enum ListingCategory {
    DEFENCE, MEDICAL, FINANCE, METALS
}
