package Problems.MEDIUM.TicketBookingSystem.Service;

public class PaymentProcessor {
    public static boolean processPayment(){
        return true;
    }
}
