package Problems.HARD.Uber.Constant;

public enum PaymentStatus {
    PENDING, COMPLETED, FAILED;
}
