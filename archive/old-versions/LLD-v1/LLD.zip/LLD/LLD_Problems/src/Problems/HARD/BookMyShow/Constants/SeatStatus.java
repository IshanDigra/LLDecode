package Problems.HARD.BookMyShow.Constants;

public enum SeatStatus {
    AVAILABLE, BOOKED;
}
