package Problems.HARD.StockBrokingSystem.Constants;

public enum OrderStatus {
    PENDING, COMPLETED, CANCELLED;
}
