package Problems.HARD.BookMyShow.Constants;

public enum SeatType {
    REGULAR, PREMIUM, VIP;
}
