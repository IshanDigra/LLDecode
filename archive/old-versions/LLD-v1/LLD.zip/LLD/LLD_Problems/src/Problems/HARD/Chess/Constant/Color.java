package Problems.HARD.Chess.Constant;

public enum Color {
    BLACK, WHITE;
}
