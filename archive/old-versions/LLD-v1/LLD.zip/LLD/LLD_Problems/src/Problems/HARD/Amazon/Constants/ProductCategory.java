package Problems.HARD.Amazon.Constants;

public enum ProductCategory {
    ELECTRONIC, CLOTHING, PERSONALCARE;
}
