package Problems.HARD.FoodDeliverySystem.Constant;

public enum ItemStatus {
    AVAILABLE, OUT_OF_STOCK
}
