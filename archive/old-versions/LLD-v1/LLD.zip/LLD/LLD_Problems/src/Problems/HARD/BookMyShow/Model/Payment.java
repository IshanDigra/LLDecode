package Problems.HARD.BookMyShow.Model;

public class Payment {
}
