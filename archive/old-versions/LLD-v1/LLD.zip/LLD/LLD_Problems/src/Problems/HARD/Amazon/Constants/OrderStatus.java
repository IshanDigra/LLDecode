package Problems.HARD.Amazon.Constants;

public enum OrderStatus {
    PENDING, COMPLETED, CANCELLED;
}
