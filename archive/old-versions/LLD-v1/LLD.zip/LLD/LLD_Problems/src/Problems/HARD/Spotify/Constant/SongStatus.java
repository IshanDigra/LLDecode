package Problems.HARD.Spotify.Constant;

public enum SongStatus {
    PLAYING, PAUSED
}
