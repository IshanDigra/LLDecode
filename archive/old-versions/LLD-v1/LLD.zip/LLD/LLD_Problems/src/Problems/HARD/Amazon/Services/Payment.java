package Problems.HARD.Amazon.Services;

public interface Payment {
    public boolean processPayment(double amount);
}
