package Problems.HARD.Spotify.Services;

import Problems.HARD.Spotify.Constant.SongType;
import Problems.HARD.Spotify.Model.Playlist;
import Problems.HARD.Spotify.Model.Song;
import Problems.HARD.Spotify.Model.User;

import java.util.ArrayList;
import java.util.List;

public class MusicRecommender {
    SongLibrary library;



//    M: recommendSongs, recommendAlbum, recommendArtist
    public List<Song> recommendSongs(SongType genre){
        // as of now based on the genre given return list of songs that are not already there for user.

        return new ArrayList<>();

    }
}
