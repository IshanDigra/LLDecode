package Problems.MEDIUM.OnlineAuctionSystem.Constant;

public enum AuctionStatus {
    ACTIVE, CLOSED
}
