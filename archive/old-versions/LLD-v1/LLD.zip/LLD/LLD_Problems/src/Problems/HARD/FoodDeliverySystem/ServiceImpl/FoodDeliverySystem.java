package Problems.HARD.FoodDeliverySystem.ServiceImpl;

public class FoodDeliverySystem {
    // not completing this as we need to first learn the observer design pattern.
}
