package Problems.MEDIUM.TicketBookingSystem.Constants;

public enum BookingStatus {
    PENDING, BOOKED, CANCELLED;
}
