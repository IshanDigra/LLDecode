package Problems.HARD.FoodDeliverySystem.Constant;

public enum RestaurantStatus {
    OPEN, CLOSED
}
