package Problems.HARD.FoodDeliverySystem.Constant;

public enum AgentStatus {
    AVAILABLE, OCCUPIED
}
