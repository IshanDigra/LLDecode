package Problems.HARD.Uber.Constant;

public enum RideType {
    REGULAR, PREMIUM, VIP;
}
