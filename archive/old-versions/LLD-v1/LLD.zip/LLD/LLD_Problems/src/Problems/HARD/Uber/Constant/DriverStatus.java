package Problems.HARD.Uber.Constant;

public enum DriverStatus {
    AVAILABLE, BUSY;
}
