package Problems.MEDIUM.TicketBookingSystem.Constants;

public enum SeatType {
    REGULAR, PREMIUM, VIP;
}
