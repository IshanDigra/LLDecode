package Problems.MEDIUM.DigitalWalletSystem.Constant;

public enum Currency {
    USD,
    EUR,
    GBP,
    JPY
}
