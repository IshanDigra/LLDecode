package Problems.HARD.Uber.Exception;

public class NoRiderAvailableException {
}
