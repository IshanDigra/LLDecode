package AsishPratapProblems.EASY.CoffeeVendingMachine.Entity;

import AsishPratapProblems.EASY.CoffeeVendingMachine.Enum.Ingredient;

public interface Observer {
    public void update(Ingredient ingredient);
}
