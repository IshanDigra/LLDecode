package AsishPratapProblems.EASY.TaskManagementSystem.TaskManagementSystem_V1.Enum;

public enum TaskStatus {
    ACTIVE, COMPLETED, DELETED
}
