package AsishPratapProblems.EASY.VendingMachine.V1.Enums;

public enum CashType {
    COIN, NOTE;
}
