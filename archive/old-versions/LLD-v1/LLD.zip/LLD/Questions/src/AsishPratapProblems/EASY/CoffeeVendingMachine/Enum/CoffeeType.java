package AsishPratapProblems.EASY.CoffeeVendingMachine.Enum;

public enum CoffeeType {
    ESPRESSO, CAPPUCCINO, LATTE
}
