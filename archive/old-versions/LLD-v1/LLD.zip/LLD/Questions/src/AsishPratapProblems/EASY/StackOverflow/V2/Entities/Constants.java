package AsishPratapProblems.EASY.StackOverflow.V2.Entities;

public class Constants {
    public static final long UPVOTE = 2;
    public static final long DOWNVOTE = -2;
    public static final long QUESTION = 10;
    public static final long ANSWER = 8;
    public static final long COMMENT = 5;
}
