package AsishPratapProblems.EASY.LoggingFrameWork.V1.Exceptions;

public class CustomExcetion extends RuntimeException {
    public CustomExcetion(String message) {
        super(message);
    }
}
