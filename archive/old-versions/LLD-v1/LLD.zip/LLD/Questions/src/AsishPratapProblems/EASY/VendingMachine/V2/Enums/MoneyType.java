package AsishPratapProblems.EASY.VendingMachine.V2.Enums;

public enum MoneyType {
    COIN, CASH
}
