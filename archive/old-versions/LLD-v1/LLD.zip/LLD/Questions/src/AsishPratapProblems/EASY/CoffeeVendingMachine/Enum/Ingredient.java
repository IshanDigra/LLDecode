package AsishPratapProblems.EASY.CoffeeVendingMachine.Enum;

public enum Ingredient {
    MILK, SUGAR, COFFEE, WATER
}
