package AsishPratapProblems.EASY.TrafficControlSystem.V2.Enums;

public enum SignalType {
    RED, GREEN, YELLOW;
}
