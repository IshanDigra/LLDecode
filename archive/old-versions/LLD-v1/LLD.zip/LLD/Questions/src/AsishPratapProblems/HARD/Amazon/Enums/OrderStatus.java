package AsishPratapProblems.HARD.Amazon.Enums;

public enum OrderStatus {
    PENDING, CONFIRMED, CANCELLED, COMPLETED
}
