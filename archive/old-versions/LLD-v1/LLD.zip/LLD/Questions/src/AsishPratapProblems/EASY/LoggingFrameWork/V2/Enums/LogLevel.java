package AsishPratapProblems.EASY.LoggingFrameWork.V2.Enums;

public enum LogLevel {
    DEBUG, INFO, WARNING, ERROR, FATAL;
}
