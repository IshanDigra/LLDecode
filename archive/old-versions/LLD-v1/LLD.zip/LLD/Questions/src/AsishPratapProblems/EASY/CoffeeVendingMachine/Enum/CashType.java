package AsishPratapProblems.EASY.CoffeeVendingMachine.Enum;

public enum CashType {
    COIN, NOTE;
}
