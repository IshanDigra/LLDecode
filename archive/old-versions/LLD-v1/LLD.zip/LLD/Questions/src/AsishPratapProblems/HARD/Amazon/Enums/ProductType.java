package AsishPratapProblems.HARD.Amazon.Enums;

public enum ProductType {
    KITCHEN_ESSENTIALS, ELECTRONICS, PERSONAL_CARE;
}
