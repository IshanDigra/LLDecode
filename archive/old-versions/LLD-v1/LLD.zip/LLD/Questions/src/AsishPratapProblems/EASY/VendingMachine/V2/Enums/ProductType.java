package AsishPratapProblems.EASY.VendingMachine.V2.Enums;

public enum ProductType {
    COOKIE, CHIPS, BAR, DRINK
}
