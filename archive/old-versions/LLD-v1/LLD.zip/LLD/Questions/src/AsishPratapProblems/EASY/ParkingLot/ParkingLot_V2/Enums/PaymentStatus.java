package AsishPratapProblems.EASY.ParkingLot.ParkingLot_V2.Enums;

public enum PaymentStatus {
    PENDING, COMPLETED;
}
