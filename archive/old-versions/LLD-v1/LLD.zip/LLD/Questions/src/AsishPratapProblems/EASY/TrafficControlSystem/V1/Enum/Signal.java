package AsishPratapProblems.EASY.TrafficControlSystem.V1.Enum;

public enum Signal {
    GREEN, YELLOW, RED;
}
