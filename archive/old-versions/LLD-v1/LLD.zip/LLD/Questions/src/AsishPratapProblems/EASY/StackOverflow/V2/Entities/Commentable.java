package AsishPratapProblems.EASY.StackOverflow.V2.Entities;

public interface Commentable {
    public void postComment(Comment comment);
}
