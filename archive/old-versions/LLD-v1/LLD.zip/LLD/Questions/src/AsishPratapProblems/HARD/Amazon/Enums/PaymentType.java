package AsishPratapProblems.HARD.Amazon.Enums;

public enum PaymentType {
    UPI, CARD
}
