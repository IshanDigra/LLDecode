package AsishPratapProblems.EASY.LoggingFrameWork.V1.Enums;

public enum LogLevel {
    DEBUG, INFO, WARNING, ERROR, FATAL
}
