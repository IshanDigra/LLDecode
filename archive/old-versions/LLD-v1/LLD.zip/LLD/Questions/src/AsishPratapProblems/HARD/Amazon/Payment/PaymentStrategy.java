package AsishPratapProblems.HARD.Amazon.Payment;

public interface PaymentStrategy {
    public boolean processPayment(double total);
}
