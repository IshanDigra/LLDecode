package AsishPratapProblems.HARD.Splitwise.Enums;

public enum SplitType {
    EQUAL, UNEQUAL, PERCENTAGE
}
