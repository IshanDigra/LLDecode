package Elevator.Enums;

public enum Direction {
    UP, DOWN;
}
