package Elevator.Enums;

public enum State {
    ACTIVE, INACTIVE;
}
