package Elevator.Models;

public class Building {
}
