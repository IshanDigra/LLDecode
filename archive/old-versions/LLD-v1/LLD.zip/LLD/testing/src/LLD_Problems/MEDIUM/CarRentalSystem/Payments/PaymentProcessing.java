package LLD_Problems.MEDIUM.CarRentalSystem.Payments;

public interface PaymentProcessing {
    boolean processPayment(double totalPrice);
}
