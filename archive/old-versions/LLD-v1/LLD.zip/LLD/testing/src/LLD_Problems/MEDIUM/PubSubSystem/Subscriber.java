package LLD_Problems.MEDIUM.PubSubSystem;

public interface Subscriber {
    void onMessage(Message msg);
}
