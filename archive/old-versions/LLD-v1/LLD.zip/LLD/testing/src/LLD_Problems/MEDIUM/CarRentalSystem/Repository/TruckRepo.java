package LLD_Problems.MEDIUM.CarRentalSystem.Repository;

public class TruckRepo implements VehicleRepository{
}
