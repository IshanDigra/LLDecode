package LLD_Problems.EASY.CoffeeVendingMachine;

public enum INGREDIENT {
    MILK, COFFEE, WATER
}
