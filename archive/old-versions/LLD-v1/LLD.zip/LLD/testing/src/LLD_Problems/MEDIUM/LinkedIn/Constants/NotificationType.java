package LLD_Problems.MEDIUM.LinkedIn.Constants;

public enum NotificationType {
    CONNECTION_REQUEST,JOB_POSTING, MESSAGE;
}
