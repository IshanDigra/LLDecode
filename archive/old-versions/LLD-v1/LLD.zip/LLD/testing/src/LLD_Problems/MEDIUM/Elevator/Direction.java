package LLD_Problems.MEDIUM.Elevator;

public enum Direction {
    UP, DOWN;
}
