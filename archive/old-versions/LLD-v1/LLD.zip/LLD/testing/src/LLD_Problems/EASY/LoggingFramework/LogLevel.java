package LLD_Problems.EASY.LoggingFramework;

public enum LogLevel {
    INFO, DEBUG , WARNING, ERROR, FATAL
}
