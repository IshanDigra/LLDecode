package LLD_Problems.MEDIUM.CarRentalSystem.Payments;

public class CashProcessing implements PaymentProcessing{
    @Override
    public boolean processPayment(double totalPrice) {
        return true;
    }
}
