package LLD_Problems.MEDIUM.CarRentalSystem.Payments;

public class UPIProcessing implements PaymentProcessing{
    @Override
    public boolean processPayment(double totalPrice) {
        return false;
    }
}
