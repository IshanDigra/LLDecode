package LLD_Problems.MEDIUM.RestaurantManagementSystem.Constatns;

public enum PaymentMethod {
    CASH, CREDIT_CARD, MOBILE_PAYMENT;
}
