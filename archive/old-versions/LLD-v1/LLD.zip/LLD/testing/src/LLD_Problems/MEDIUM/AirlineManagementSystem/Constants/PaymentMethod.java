package LLD_Problems.MEDIUM.AirlineManagementSystem.Constants;

public enum PaymentMethod {
    UPI, CREDITCARD, CASH;
}
