package LLD_Problems.MEDIUM.FaceBook.Constants;

public enum NotificationType {
    FRIEND_REQUEST, LIKE, COMMENT, MENTION;
}
