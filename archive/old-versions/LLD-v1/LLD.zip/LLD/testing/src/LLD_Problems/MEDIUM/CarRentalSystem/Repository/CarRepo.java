package LLD_Problems.MEDIUM.CarRentalSystem.Repository;

public class CarRepo implements VehicleRepository{
}
