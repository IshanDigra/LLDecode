package LLD_Problems.MEDIUM.LibraryManagementSystem.Constants;

public enum LoanStatus {
    ACTIVE, RETURNED, OVERDUE;
}
