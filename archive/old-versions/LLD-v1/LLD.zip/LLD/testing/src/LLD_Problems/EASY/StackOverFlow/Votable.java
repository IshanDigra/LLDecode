package LLD_Problems.EASY.StackOverFlow;

import java.util.List;

public interface Votable {
    public void vote(User user, int Value);
    public int getVoteCount();
}
