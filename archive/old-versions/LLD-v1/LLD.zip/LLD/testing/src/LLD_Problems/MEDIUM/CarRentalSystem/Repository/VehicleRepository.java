package LLD_Problems.MEDIUM.CarRentalSystem.Repository;

public interface VehicleRepository {
}
