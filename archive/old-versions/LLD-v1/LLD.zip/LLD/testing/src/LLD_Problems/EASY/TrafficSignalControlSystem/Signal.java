package LLD_Problems.EASY.TrafficSignalControlSystem;

public enum Signal {
    GREEN, YELLOW, RED
}
