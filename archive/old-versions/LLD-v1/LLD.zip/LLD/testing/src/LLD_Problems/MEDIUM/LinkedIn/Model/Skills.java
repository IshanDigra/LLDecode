package LLD_Problems.MEDIUM.LinkedIn.Model;

public class Skills {
    String skill;
}
