package LLD_Problems.MEDIUM.HotelManagement.Payment;

import LLD_Problems.MEDIUM.CarRentalSystem.Customer;

public interface Payment {
    boolean processPayment(double amount);
}
