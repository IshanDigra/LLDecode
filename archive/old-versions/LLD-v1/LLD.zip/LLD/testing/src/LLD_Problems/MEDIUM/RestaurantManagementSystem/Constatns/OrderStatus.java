package LLD_Problems.MEDIUM.RestaurantManagementSystem.Constatns;

public enum OrderStatus {
    PENDING, PREPARING, READY, COMPLETED, CANCELLED;
}
