package LLD_Problems.MEDIUM.HotelManagement.Constants;

public enum ReservationStatus {
    CONFIRMED,CANCELLED;
}
