package LLD_Problems.MEDIUM.RestaurantManagementSystem.Constatns;

public enum PaymentStatus {
    PENDING, COMPLETED, FAILED;
}
