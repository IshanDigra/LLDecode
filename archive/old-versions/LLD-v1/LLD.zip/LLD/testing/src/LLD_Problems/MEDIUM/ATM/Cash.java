package LLD_Problems.MEDIUM.ATM;

public enum Cash {
    Thousand, FiveHundred, Hundred;
}
