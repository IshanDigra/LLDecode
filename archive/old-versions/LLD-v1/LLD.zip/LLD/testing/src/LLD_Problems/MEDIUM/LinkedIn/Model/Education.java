package LLD_Problems.MEDIUM.LinkedIn.Model;

public class Education {
    private String school;
    private String degree;
    private String major;
    private String startDate;
    private String endDate;

    public Education(String school, String degree, String major, String startDate, String endDate) {
        this.school = school;
        this.degree = degree;
        this.major = major;
        this.startDate = startDate;
        this.endDate = endDate;
    }
}
