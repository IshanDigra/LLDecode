package LLD_Problems.MEDIUM.HotelManagement.Constants;

public enum RoomType {
    SINGLE, DOUBLE, DELUXE, SUITE;
}
