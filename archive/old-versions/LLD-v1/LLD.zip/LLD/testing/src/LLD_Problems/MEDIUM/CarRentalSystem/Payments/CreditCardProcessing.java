package LLD_Problems.MEDIUM.CarRentalSystem.Payments;

public class CreditCardProcessing implements PaymentProcessing{
    @Override
    public boolean processPayment(double totalPrice) {
        return true;
    }
}
