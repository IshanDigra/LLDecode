package LLD_Problems.MEDIUM.AirlineManagementSystem.Constants;

public enum BookingStatus {
    APPROVED, PENDING, CANCELLED;
}
