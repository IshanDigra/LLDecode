package LLD_Problems.MEDIUM.AirlineManagementSystem.Constants;

public enum PaymentStatus {
    COMPLETED, PENDING, FAILED;
}
