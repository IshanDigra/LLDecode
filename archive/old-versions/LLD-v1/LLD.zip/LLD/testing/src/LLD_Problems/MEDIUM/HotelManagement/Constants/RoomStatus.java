package LLD_Problems.MEDIUM.HotelManagement.Constants;

public enum RoomStatus {
    BOOKED, AVAILABLE, OCCUPIED;
}
