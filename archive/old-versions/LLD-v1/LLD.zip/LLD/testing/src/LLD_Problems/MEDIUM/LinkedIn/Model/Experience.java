package LLD_Problems.MEDIUM.LinkedIn.Model;

public class Experience {
    private String title;
    private String company;
    private String startDate;
    private String endDate;
    private String description;
}
